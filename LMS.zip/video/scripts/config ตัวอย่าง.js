var isoffline = false;/*set offline*/
var islinear = true;/*set linear learning*/
var completedWhenDoAllMasteryscore = true;/*set complete condition do all exam, that have masteryscore greater than 0 */
var isResume = true;/* set resume last page when exit */
var treeArray = [
{ parent : "#", id : "chapter1", ispage : false, state : { opened : true }, text : "การบริหารจัดการความปลอดภัยสารเคมี", detail : ""}


,{ parent : "chapter1", id : "chapter1page0", ispage : true, url : "data/m00/index.html", urlOffline : "data/m00/index.html", text : "กิจกรรม", detail : "",activity : true, atcp : false,  playicon : true, calculatescore : false, duration : "1:14:04"}

,{ parent : "chapter1", id : "chapter1page1", ispage : true, url : "data/m01/index.html", urlOffline : "data/m01/index.html", text : "บทที่ 1: แนวทางชี้บ่งสารเคมีอันตรายในโรงงาน", detail : "",activity : true, atcp : false,  playicon : true, calculatescore : false, duration : "36:19"}

,{ parent : "chapter1", id : "posttest1", ispage : true, url : "data/posttest1/index.html", text : "เเบบทดสอบหลังบทที่ 1", detail : "", activity : true, masteryscore : 80, playicon : false,stepBackward: 1 , duration : "",resetBackward : true, resetwhenquizzed : 3}

,{ parent : "chapter2", id : "chapter1page2", ispage : true, url : "data/m02/index.html", urlOffline : "data/m02/index.html", text : "บทที่ 2: การสื่อสารความอันตรายของสารเคมี", detail : "", activity : true, atcp : false,  playicon : true, calculatescore : false, duration : "43:02"}

,{ parent : "chapter1", id : "posttest2", ispage : true, url : "data/posttest2/index.html", text : "เเบบทดสอบหลังบทที่ 2", detail : "", activity : true, masteryscore : 80, playicon : false,stepBackward: 1 , duration : "",resetBackward : true, resetwhenquizzed : 3}

,{ parent : "chapter3", id : "chapter1page3", ispage : true, url : "data/m03/index.html", urlOffline : "data/m03/index.html", text : "บทที่ 3: การบริหารจัดการความปลอดภัยในการใช้งานสารเคมีอันตราย", detail : "", activity : true, atcp : false, playicon : true, calculatescore : false, duration : "39:09"}

,{ parent : "chapter1", id : "posttest3", ispage : true, url : "data/posttest3/index.html", text : "เเบบทดสอบหลังบทที่ 3", detail : "", activity : true, masteryscore : 80, playicon : false,stepBackward: 1 , duration : "",resetBackward : true, resetwhenquizzed : 3}

,{ parent : "chapter1", id : "chapter1page4", ispage : true, url : "data/m04/index.html", urlOffline : "data/m04/index.html", text : "บทที่ 4: มาตรการความปลอดภัยการใช้และจัดเก็บสารเคมีอันตราย", detail : "", activity : true, atcp : false, playicon : true, calculatescore : false, duration : "38:46"}

,{ parent : "chapter1", id : "posttest4", ispage : true, url : "data/posttest4/index.html", text : "เเบบทดสอบหลังบทที่ 4", detail : "", activity : true, masteryscore : 80, playicon : false,stepBackward: 1 , duration : "",resetBackward : true, resetwhenquizzed : 3}

,{ parent : "chapter1", id : "chapter1page5", ispage : true, url : "data/m05/index.html", urlOffline : "data/m05/index.html", text : "บทที่ 5: ขั้นตอนการตอบโต้สถานการณ์ฉุกเฉินสารเคมีอันตราย", detail : "", activity : true, atcp : false, playicon : true, calculatescore : false, duration : "41:20"}

,{ parent : "chapter1", id : "posttest5", ispage : true, url : "data/posttest5/index.html", text : "เเบบทดสอบหลังบทที่ 5", detail : "", activity : true, masteryscore : 80, playicon : false,stepBackward: 1 , duration : "",resetBackward : true, resetwhenquizzed : 3}

];/*change here*/

Content = {};

Content.CourseActivity = {
    id: "https://www.diw.go.th/lrs_new/Chemical_safety_management",/*change here*/
    definition: {
        type: "http://adlnet.gov/expapi/activities/course",
        name: {
            "th-TH": "การบริหารจัดการความปลอดภัยสารเคมี"/*change here*/
        },
        description: {
            "th-TH": "การบริหารจัดการความปลอดภัยสารเคมี"/*change here*/
        }
    }
};

Content.getContext = function(parentActivityId) {
var ctx = {
contextActivities: {
/*grouping: {
id: Content.CourseActivity.id
}*/
}
};
/*if (parentActivityId !== undefined && parentActivityId !== null) {*/
ctx.contextActivities.parent = {
id: Content.CourseActivity.id,
definition: {
name: Content.CourseActivity.definition.name,
description: Content.CourseActivity.definition.description
}
};
/*}*/
return ctx;
};